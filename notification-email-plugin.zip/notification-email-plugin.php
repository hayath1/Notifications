<?php
/*
Plugin Name: Notification Email Plugin
Description: Sends a notification email when a post is published.
Version: 1.0
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Hook into the publish_post action to send notification emails
add_action('publish_post', 'send_notification_email', 10, 2);

/**
 * Sends a notification email when a new post is published.
 *
 * @param int $post_id The ID of the published post.
 * @param WP_Post $post The post object.
 */
function send_notification_email($post_id, $post) {
    // Get the admin email from WordPress settings
    $admin_email = get_option('admin_email');
    
    // Prepare the email subject
    $subject = "New Post Published: " . $post->post_title;
    
    // Prepare the email message
    $message = "A new post has been published on your website: \n\n";
    $message .= "Title: " . $post->post_title . "\n";
    $message .= "Content: " . $post->post_content . "\n\n";
    $message .= "You can view it here: " . get_permalink($post_id) . "\n\n";
    $message .= "Thank you,\nYour Website";
    
    // Send the email
    wp_mail($admin_email, $subject, $message);
}
